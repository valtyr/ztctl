from distutils.core import setup

try:  # for pip >= 10
    from pip._internal.req import parse_requirements
except ImportError:  # for pip <= 9.0.3
    from pip.req import parse_requirements

install_reqs = parse_requirements('requirements.txt', session='hack')

setup(
    name='ztctl',
    packages=['ztctl'],
    version='0.1',
    license='MIT',
    description='Zerotier controller bindings for python',
    author='Valtýr Örn Kjartansson',
    author_email='valtyr@gmail.com',
    url='https://github.com/valtyr/ztctl',
    download_url='https://github.com/valtyr/ztctl/archive/v0.1.tar.gz',
    keywords=['zerotier', 'zerotier-cli', 'ztctl'],
    install_requires=[str(ir.req) for ir in install_reqs],
    classifiers=[
        # "3 - Alpha", "4 - Beta" or "5 - Production/Stable"
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        # Language support
        'Programming Language :: Python :: 3.6',
    ],
)
